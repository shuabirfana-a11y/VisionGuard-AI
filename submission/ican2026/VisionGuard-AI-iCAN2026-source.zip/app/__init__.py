"""VisionGuard AI application package."""

