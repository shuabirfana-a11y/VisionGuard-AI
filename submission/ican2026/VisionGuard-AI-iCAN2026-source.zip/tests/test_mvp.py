from io import BytesIO
import asyncio

import httpx
from PIL import Image

from app.core.agent import VisionGuardAgent
from app.services.knowledge import SafetyKnowledgeService
from app.services.report import SafetyReportService
from app.services.reasoning.deterministic import DeterministicReasoner
from app.services.risk import RiskAnalysisService
from app.services.vision.demo import DemoColorDetector
from app.main import app


def image_bytes(color: tuple[int, int, int]) -> bytes:
    buffer = BytesIO()
    Image.new("RGB", (120, 80), color=color).save(buffer, format="PNG")
    return buffer.getvalue()


def test_demo_detector_returns_structured_fire_evidence():
    result = asyncio.run(DemoColorDetector().detect(image_bytes((230, 90, 25)), "fire.png"))
    assert result.detector == "demo-color-heuristic-v1"
    assert result.inference.model_version == "1.0-demo"
    assert result.inference.inference_ms >= 0
    assert result.detections[0].category == "fire"
    assert result.detections[0].bbox.x2 == 120


def test_agent_runs_complete_tool_chain():
    agent = VisionGuardAgent(
        detector=DemoColorDetector(),
        knowledge=SafetyKnowledgeService(),
        risk=RiskAnalysisService(),
        report=SafetyReportService(),
        reasoner=DeterministicReasoner(),
    )
    result = asyncio.run(agent.analyze(image_bytes((230, 90, 25)), "scene.png", "分析火灾风险"))
    assert result.risk.overall_level in {"high", "critical"}
    assert [step.tool for step in result.agent_trace] == [
        "agent.plan",
        "vision.detect",
        "knowledge.retrieve",
        "risk.analyze",
        "reasoning.explain",
        "report.generate",
    ]
    assert result.report.disclaimer


def test_agent_planner_distinguishes_visual_explanation_and_action_intents():
    visual = VisionGuardAgent._plan_task("请检测图片并定位烟雾")
    explanation = VisionGuardAgent._plan_task("为什么判断存在风险，请给出法规依据")
    action = VisionGuardAgent._plan_task("生成处置建议和应急报告")
    assert visual.intent == "视觉目标定位"
    assert explanation.intent == "证据解释与依据核查"
    assert "安全知识依据" in explanation.requested_outputs
    assert action.intent == "风险处置与报告"
    assert "结构化安全报告" in action.requested_outputs
    assert visual.tool_sequence == action.tool_sequence
    assert len(action.safety_constraints) == 3


def test_knowledge_retrieval_exposes_authority_and_applicability():
    service = SafetyKnowledgeService()
    results = asyncio.run(
        service.retrieve(["fire"], "分析火灾风险并生成报警疏散建议")
    )
    assert results[0].rule_id == "LAW-FIRE-044"
    assert results[0].authority_level == "law"
    assert results[0].source_url.startswith("https://")
    assert "现场确认" in results[0].applicability
    assert len(results) == 3


def test_no_detection_boundary_is_not_mislabeled_as_law():
    results = asyncio.run(
        SafetyKnowledgeService().retrieve([], "没有检出是否代表安全")
    )
    assert results[0].rule_id == "VG-NONE-BOUNDARY"
    assert results[0].authority_level == "internal_method"
    assert results[0].source_url is None


def test_hybrid_rag_is_explainable_and_does_not_cross_risk_categories():
    results = asyncio.run(
        SafetyKnowledgeService().retrieve(
            ["smoke"], "白色羽流可能是蒸汽或粉尘，如何复核误报"
        )
    )
    assert results
    assert {item.matched_category for item in results} == {"smoke"}
    assert all(
        item.retrieval_method == "category-constrained-tfidf-rag-v1"
        for item in results
    )
    assert {"蒸汽", "粉尘"}.intersection(results[0].matched_terms)


def test_http_api_accepts_image_and_returns_agent_trace():
    async def request():
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            return await client.post(
                "/api/v1/analyze",
                files={"image": ("scene.png", image_bytes((230, 90, 25)), "image/png")},
                data={"task": "检查图片中的工业安全风险"},
            )

    response = asyncio.run(request())
    assert response.status_code == 200
    body = response.json()
    assert body["vision"]["detections"][0]["category"] == "fire"
    assert body["vision"]["inference"]["confidence_threshold"] == 0.35
    assert body["reasoning"]["used_llm"] is False
    assert body["reasoning"]["evidence_ids"] == ["ev-fire-001"]
    assert len(body["agent_trace"]) == 6
    assert all(step["duration_ms"] >= 0 for step in body["agent_trace"])
    assert body["agent_plan"]["intent"] == "风险识别与等级研判"
    assert body["agent_plan"]["tool_sequence"][0] == "vision.detect"
    assert body["agent_trace"][1]["references"] == ["ev-fire-001"]
    assert body["agent_trace"][2]["references"]
